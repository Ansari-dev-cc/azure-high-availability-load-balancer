#!/usr/bin/env bash
# CPU Stress Test & Cleanup on vm-web1
set -euo pipefail
sudo apt update
sudo apt install stress -y
stress --cpu 2 --timeout 300

# Cleanup after verifying metrics in Azure Monitor
sudo pkill stress || true
sudo apt remove stress -y
sudo apt autoremove -y

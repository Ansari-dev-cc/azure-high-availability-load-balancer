#!/usr/bin/env bash
# Run on vm-web2 (10.0.1.5 / 4.227.208.195)
set -euo pipefail
sudo apt update
sudo apt install nginx -y
echo "<h1>Hello from Web Server 2 (vm-web2)</h1><p>Highly Available Web App</p>" | sudo tee /var/www/html/index.html
sudo systemctl enable nginx
sudo systemctl status nginx --no-pager

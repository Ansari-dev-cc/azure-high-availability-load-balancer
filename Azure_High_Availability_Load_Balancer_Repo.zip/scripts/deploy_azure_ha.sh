#!/usr/bin/env bash
# ==============================================================================
# Cloud High Availability: Azure Load Balancer & Availability Set Integration
# Automated Infrastructure Provisioning Script (Azure CLI)
# ==============================================================================
set -euo pipefail

RG="RG-CoreTask4"
LOCATION="eastus"
VNET="vnet-ha"
SUBNET="subnet-web"
NSG="nsg-web"
AVSET="avset-web"
LB="lb-web"
LB_PIP="pip-lb"

echo "[1/7] Creating Resource Group ${RG} in ${LOCATION}..."
az group create --name "$RG" --location "$LOCATION"

echo "[2/7] Creating Virtual Network ${VNET} (10.0.0.0/16) and Subnet ${SUBNET} (10.0.1.0/24)..."
az network vnet create \
  --resource-group "$RG" \
  --name "$VNET" \
  --address-prefixes 10.0.0.0/16 \
  --subnet-name "$SUBNET" \
  --subnet-prefixes 10.0.1.0/24

echo "[3/7] Creating Network Security Group ${NSG} and Inbound Rules (HTTP 80, SSH 22)..."
az network nsg create --resource-group "$RG" --name "$NSG"

az network nsg rule create \
  --resource-group "$RG" \
  --nsg-name "$NSG" \
  --name "Allow-HTTP" \
  --priority 100 \
  --protocol Tcp \
  --destination-port-ranges 80 \
  --access Allow

az network nsg rule create \
  --resource-group "$RG" \
  --nsg-name "$NSG" \
  --name "Allow-SSH" \
  --priority 110 \
  --protocol Tcp \
  --destination-port-ranges 22 \
  --access Allow

az network vnet subnet update \
  --resource-group "$RG" \
  --vnet-name "$VNET" \
  --name "$SUBNET" \
  --network-security-group "$NSG"

echo "[4/7] Creating Availability Set ${AVSET} (2 Fault Domains, 5 Update Domains)..."
az vm availability-set create \
  --resource-group "$RG" \
  --name "$AVSET" \
  --platform-fault-domain-count 2 \
  --platform-update-domain-count 5

echo "[5/7] Deploying Ubuntu 24.04 LTS VMs (vm-web1 & vm-web2)..."
for i in 1 2; do
  az vm create \
    --resource-group "$RG" \
    --name "vm-web${i}" \
    --availability-set "$AVSET" \
    --image Canonical:ubuntu-24_04-lts:server:latest \
    --size Standard_D2als_v7 \
    --admin-username Azureuser \
    --vnet-name "$VNET" \
    --subnet "$SUBNET" \
    --public-ip-address "vm-web${i}-ip" \
    --public-ip-sku Standard \
    --nsg ""
done

echo "[6/7] Creating Standard Public Load Balancer ${LB} with Frontend IP ${LB_PIP}..."
az network public-ip create \
  --resource-group "$RG" \
  --name "$LB_PIP" \
  --sku Standard \
  --zone 1 2 3

az network lb create \
  --resource-group "$RG" \
  --name "$LB" \
  --sku Standard \
  --public-ip-address "$LB_PIP" \
  --frontend-ip-name "lb-frontend" \
  --backend-pool-name "backend-pool"

az network lb probe create \
  --resource-group "$RG" \
  --lb-name "$LB" \
  --name "probe-http" \
  --protocol tcp \
  --port 80

az network lb rule create \
  --resource-group "$RG" \
  --lb-name "$LB" \
  --name "rule-http" \
  --protocol tcp \
  --frontend-port 80 \
  --backend-port 80 \
  --frontend-ip-name "lb-frontend" \
  --backend-pool-name "backend-pool" \
  --probe-name "probe-http" \
  --idle-timeout 4

echo "[7/7] Adding vm-web1 and vm-web2 NICs to backend-pool..."
for i in 1 2; do
  NIC_NAME=$(az vm show -g "$RG" -n "vm-web${i}" --query 'networkProfile.networkInterfaces[0].id' -o tsv | awk -F/ '{print $NF}')
  az network nic ip-config address-pool add \
    --resource-group "$RG" \
    --nic-name "$NIC_NAME" \
    --ip-config-name "ipconfig1" \
    --lb-name "$LB" \
    --address-pool "backend-pool"
done

echo "Deployment complete!"

#!/usr/bin/env bash
# Run on vm-web1 (10.0.1.4 / 13.82.138.244)
set -euo pipefail
sudo apt update
sudo apt install nginx -y
echo "<h1>Hello from Web Server 1 (vm-web1)</h1><p>Highly Available Web App</p>" | sudo tee /var/www/html/index.html
sudo systemctl enable nginx
sudo systemctl status nginx --no-pager
